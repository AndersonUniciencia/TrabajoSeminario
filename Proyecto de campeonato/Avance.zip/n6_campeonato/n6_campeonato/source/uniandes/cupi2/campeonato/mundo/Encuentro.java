package uniandes.cupi2.campeonato.mundo;

public class Encuentro {

}
