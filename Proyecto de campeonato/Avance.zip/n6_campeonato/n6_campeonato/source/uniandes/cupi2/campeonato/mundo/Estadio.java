package uniandes.cupi2.campeonato.mundo;

public class Estadio {
	// -----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------

    /**
     * El nombre del equipo.
     */
    private String nombre;

    /**
     * La ruta del logo del equipo.
     */
    private String ruta;
    
    private String ubicacion;

    // -----------------------------------------------------------------
    // Constructores
    // -----------------------------------------------------------------

    /**
     * Construye una nueva instancia de un equipo.
     * @param pNombreEquipo El nombre del equipo. pNombreEquipo != null && pNombreEquipo != "".
     * @param pRuta La ruta del logo del equipo. pEquipo != null && pEquipo != "".
     */
    public Estadio( String pNombreEquipo, String pRuta, String pUbicacion)
    {
        nombre = pNombreEquipo;
        ruta = pRuta;
        ubicacion = pUbicacion;
    }

    // -----------------------------------------------------------------
    // M�todos
    // -----------------------------------------------------------------

    /**
     * Retorna el nombre del equipo.
     * @return El nombre del equipo.
     */
    public String darNombre( )
    {
        return nombre;
    }

    /**
     * Retorna el ruta del equipo.
     * @return La ruta del equipo.
     */
    public String darRuta( )
    {
        return ruta;
    }
    
    public String darUbicacion( )
    {
        return ubicacion;
    }

    /**
     * Retorna una representaci�n como cadena de caracteres del equipo.
     * @return El nombre del equipo.
     */
    public String toString( )
    {
        return nombre;
    }
}
